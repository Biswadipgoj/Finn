'use client';
import { useState, useEffect } from 'react';
import { Customer, EMISchedule, DueBreakdown } from '@/lib/types';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { calculateTotalFineFromEmis } from '@/lib/fineCalc';
import FineSummaryPanel from './FineSummaryPanel';
import { formatCurrency, formatDateOnly } from '@/lib/formatters';

interface Props { customer: Customer; emis: EMISchedule[]; breakdown: DueBreakdown | null; onClose: () => void; onSubmitted: () => void; isAdmin?: boolean; }
const UPI_ID = 'biswajit.khanra82@axl';

export default function PaymentModal({ customer, emis, breakdown, onClose, onSubmitted, isAdmin }: Props) {
  const unpaidEmis = emis.filter(e => e.status === 'UNPAID');
  const defaultEmiNo = breakdown?.next_emi_no ?? unpaidEmis[0]?.emi_no ?? 0;
  const [selectedEmiNo, setSelectedEmiNo] = useState(defaultEmiNo);
  const [mode, setMode] = useState<'CASH' | 'UPI'>('CASH');
  const [utr, setUtr] = useState('');
  const [retailerPin, setRetailerPin] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [showReceipt, setShowReceipt] = useState(false);
  const [receiptId, setReceiptId] = useState('');
  const [showFineSummary, setShowFineSummary] = useState(false);

  // CHECKBOX-BASED: auto-tick what's due, user can manually untick
  const selectedEmi = unpaidEmis.find(e => e.emi_no === selectedEmiNo) || emis.find(e => e.emi_no === selectedEmiNo);
  const scheduledEmiAmount = selectedEmi?.amount ?? 0;
  const autoFine = calculateTotalFineFromEmis(emis);
  const scheduledFine = Math.max(breakdown?.fine_due ?? 0, autoFine);
  const scheduledCharge = breakdown?.first_emi_charge_due ?? (customer.first_emi_charge_paid_at ? 0 : (customer.first_emi_charge_amount || 0));

  const [collectEmi, setCollectEmi] = useState(unpaidEmis.length > 0);
  const [collectFine, setCollectFine] = useState(scheduledFine > 0);
  const [collectCharge, setCollectCharge] = useState(scheduledCharge > 0);

  // Editable amounts (survive checkbox toggles)
  const [editEmi, setEditEmi] = useState('');
  const [editFine, setEditFine] = useState('');
  const [editCharge, setEditCharge] = useState('');

  // Computed amounts
  const emiAmt = collectEmi ? (editEmi !== '' ? Math.max(0, parseFloat(editEmi) || 0) : scheduledEmiAmount) : 0;
  const fineAmt = collectFine ? (editFine !== '' ? Math.max(0, parseFloat(editFine) || 0) : scheduledFine) : 0;
  const chargeAmt = collectCharge ? (editCharge !== '' ? Math.max(0, parseFloat(editCharge) || 0) : scheduledCharge) : 0;
  const total = emiAmt + fineAmt + chargeAmt;
  const missingRetailPin = !isAdmin && !retailerPin.trim();
  const missingUtr = mode === 'UPI' && !utr.trim();
  const cannotSubmit = loading || total <= 0 || missingRetailPin || missingUtr || (collectEmi && !selectedEmi);

  // Auto-tick what's due when fine/charge changes
  useEffect(() => { setCollectFine(scheduledFine > 0); setCollectCharge(scheduledCharge > 0); }, [scheduledFine, scheduledCharge]);
  useEffect(() => { if (selectedEmiNo === 0 && unpaidEmis.length > 0) setSelectedEmiNo(unpaidEmis[0].emi_no); }, [selectedEmiNo, unpaidEmis]);
  useEffect(() => { setEditEmi(''); setEditFine(''); setEditCharge(''); }, [selectedEmiNo]);

  // QR
  useEffect(() => {
    if (mode === 'UPI' && total > 0) {
      import('qrcode').then(QR => {
        QR.toDataURL(`upi://pay?pa=${UPI_ID}&pn=TelePoint&am=${total}&tn=EMI${selectedEmiNo}_${customer.imei.slice(-6)}&cu=INR`, { width: 240, margin: 2, color: { dark: '#1e293b', light: '#ffffff' } }).then(setQrDataUrl);
      }).catch(() => {});
    } else setQrDataUrl('');
  }, [mode, total, selectedEmiNo, customer.imei]);

  // Derive collect_type for API
  function getCollectType() {
    if (collectEmi && collectFine && collectCharge) return 'emi_full_due';
    if (collectEmi && collectFine) return 'emi_fine';
    if (collectEmi && collectCharge) return 'emi_first_charge';
    if (collectEmi) return 'emi_only';
    if (collectFine) return 'fine_only';
    if (collectCharge) return 'first_charge_only';
    return 'emi_only';
  }

  async function handleSubmit() {
    if (collectEmi && !selectedEmi) { toast.error('Select an EMI'); return; }
    if (!isAdmin && !retailerPin.trim()) { toast.error('Enter Retail PIN'); return; }
    if (mode === 'UPI' && !utr.trim()) { toast.error('UTR required for UPI'); return; }
    if (total <= 0) { toast.error('Total must be > 0'); return; }
    setLoading(true);
    try {
      const res = await fetch(isAdmin ? '/api/payments/approve-direct' : '/api/payments/submit', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: customer.id,
          emi_ids: collectEmi && selectedEmi ? [selectedEmi.id] : [],
          emi_nos: collectEmi && selectedEmi ? [selectedEmi.emi_no] : [],
          mode, utr: mode === 'UPI' ? utr.trim() : null, notes: notes || null,
          retail_pin: isAdmin ? undefined : retailerPin,
          total_emi_amount: emiAmt, scheduled_emi_amount: scheduledEmiAmount,
          fine_amount: fineAmt, first_emi_charge_amount: chargeAmt,
          total_amount: total,
          fine_for_emi_no: fineAmt > 0 ? selectedEmiNo : undefined,
          fine_due_date: fineAmt > 0 && selectedEmi ? selectedEmi.due_date : undefined,
          collected_by_role: isAdmin ? 'admin' : 'retailer',
          collect_type: getCollectType(),
        }),
      });
      const data = await res.json().catch(() => ({ error: 'Server error' }));
      if (!res.ok) toast.error(data.error || 'Failed');
      else {
        toast.success(isAdmin ? '✅ Payment approved!' : '📋 Request submitted');
        if (data.request_id) { setReceiptId(data.request_id); setShowReceipt(true); }
        else { onSubmitted(); onClose(); }
      }
    } catch (e: unknown) { toast.error('Failed: ' + (e instanceof Error ? e.message : '')); }
    finally { setLoading(false); }
  }

  if (showReceipt && receiptId) {
    const now = new Date();
    return (
      <div className="modal-backdrop" onClick={e => { if (e.target === e.currentTarget) { onSubmitted(); onClose(); } }}>
        <div className="modal-panel max-w-sm mx-auto animate-scale-in">
          <div className="bg-brand-500 px-6 py-5 text-center"><div className="text-4xl mb-2">{isAdmin ? '✅' : '📋'}</div><h2 className="text-white font-bold text-xl">{isAdmin ? 'Payment Approved' : 'Request Submitted'}</h2></div>
          <div className="p-5 space-y-3">
            <div className="card bg-surface-2 p-4 space-y-2">
              <div className="flex justify-between text-sm"><span className="text-ink-muted">Customer</span><span className="font-semibold text-ink">{customer.customer_name}</span></div>
              <div className="flex justify-between text-sm"><span className="text-ink-muted">IMEI</span><span className="num text-ink">{customer.imei}</span></div>
              {emiAmt > 0 && <div className="flex justify-between text-sm"><span className="text-ink-muted">EMI #{selectedEmiNo}</span><span className="num font-semibold">{formatCurrency(emiAmt)}</span></div>}
              {chargeAmt > 0 && <div className="flex justify-between text-sm"><span className="text-warning">1st Charge</span><span className="num text-warning">{formatCurrency(chargeAmt)}</span></div>}
              {fineAmt > 0 && <div className="flex justify-between text-sm"><span className="text-danger">Fine</span><span className="num text-danger">{formatCurrency(fineAmt)}</span></div>}
              <div className="h-px bg-surface-4" />
              <div className="flex justify-between"><span className="font-bold">Total</span><span className="num text-xl font-bold text-brand-600">{formatCurrency(total)}</span></div>
            </div>
            <button onClick={() => { const m = [`🧾 *TelePoint EMI Receipt*`,'',`👤 ${customer.customer_name}`,`📱 ${customer.mobile}`,`🔢 IMEI: ${customer.imei}`,'',emiAmt>0?`💳 EMI #${selectedEmiNo}: ${formatCurrency(emiAmt)}`:'',chargeAmt>0?`⭐ Charge: ${formatCurrency(chargeAmt)}`:'',fineAmt>0?`⚠️ Fine: ${formatCurrency(fineAmt)}`:'',`💰 *Total: ${formatCurrency(total)}*`,`🏷️ ${mode}`,`📅 ${format(now,'d MMM yyyy, h:mm a')}`,'','— TelePoint'].filter(Boolean).join('\n'); window.open(`https://wa.me/?text=${encodeURIComponent(m)}`,'_blank'); }} className="btn w-full py-3 bg-green-500 hover:bg-green-600 text-white">📤 Share WhatsApp</button>
            <button onClick={() => { onSubmitted(); onClose(); }} className="btn-ghost w-full py-2.5">Close</button>
          </div>
        </div>
      </div>
    );
  }

  if (showFineSummary) return <FineSummaryPanel emis={emis} onClose={() => setShowFineSummary(false)} />;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Payment collection form" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-panel flex flex-col h-[100dvh] sm:h-auto sm:max-h-[92vh]">
        <div className="sticky top-0 z-10 bg-white border-b border-surface-4 px-4 py-3 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-ink text-base sm:text-lg">{isAdmin ? 'Update Payment' : 'Collect Payment'}</h2>
            <p className="text-ink-muted text-xs mt-0.5">{customer.customer_name} · {customer.mobile}</p>
          </div>
          <button aria-label="Close payment modal" onClick={onClose} className="btn-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
        <div className="flex-1 p-4 space-y-4 overflow-y-auto pb-32 sm:pb-8">
          <div className="card bg-surface-2 p-4">
            <p className="text-sm font-semibold text-ink">{customer.customer_name}</p>
            <p className="text-xs text-ink-muted mt-1">Mobile: {customer.mobile} · IMEI: {customer.imei}</p>
          </div>
          {/* WHAT TO COLLECT — checkboxes */}
          <div className="card bg-surface-2 p-4 space-y-3">
            <p className="text-sm font-semibold text-ink-muted">EMI and Fine Details</p>
            <label className={`flex items-center justify-between p-3 rounded-xl border-2 cursor-pointer transition-all ${collectEmi ? 'border-brand-400 bg-brand-50' : 'border-surface-4'}`}>
              <div className="flex items-center gap-3">
                <input type="checkbox" checked={collectEmi} onChange={e => setCollectEmi(e.target.checked)} className="w-5 h-5 accent-brand-500 rounded" />
                  <div><p className="text-sm font-semibold text-ink">EMI #{selectedEmiNo || '—'}</p><p className="text-xs text-ink-muted">EMI Amount: {formatCurrency(scheduledEmiAmount)}</p></div>
              </div>
              <span className="num font-semibold text-ink">{formatCurrency(scheduledEmiAmount)}</span>
            </label>
            {scheduledFine > 0 && (
              <label className={`flex items-center justify-between p-3 rounded-xl border-2 cursor-pointer transition-all ${collectFine ? 'border-danger bg-danger-light' : 'border-surface-4'}`}>
                <div className="flex items-center gap-3">
                  <input type="checkbox" checked={collectFine} onChange={e => setCollectFine(e.target.checked)} className="w-5 h-5 accent-red-500 rounded" />
                  <div><p className="text-sm font-semibold text-danger">Fine Due</p><p className="text-xs text-ink-muted">Calculated based on payment timing</p></div>
                </div>
                <span className="num font-semibold text-danger">{formatCurrency(scheduledFine)}</span>
              </label>
            )}
            {scheduledCharge > 0 && (
              <label className={`flex items-center justify-between p-3 rounded-xl border-2 cursor-pointer transition-all ${collectCharge ? 'border-warning bg-warning-light' : 'border-surface-4'}`}>
                <div className="flex items-center gap-3">
                  <input type="checkbox" checked={collectCharge} onChange={e => setCollectCharge(e.target.checked)} className="w-5 h-5 accent-amber-500 rounded" />
                  <div><p className="text-sm font-semibold text-warning">First EMI Charge</p><p className="text-xs text-ink-muted">One-time amount</p></div>
                </div>
                <span className="num font-semibold text-warning">{formatCurrency(scheduledCharge)}</span>
              </label>
            )}
          </div>

          {/* Fine Summary button */}
          {scheduledFine > 0 && (
            <button type="button" onClick={() => setShowFineSummary(true)} className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl border border-danger-border bg-danger-light text-left hover:border-danger transition-all">
              <span className="text-sm font-semibold text-danger">Fine Details</span>
              <span className="text-xs text-danger">View →</span>
            </button>
          )}

          {/* EMI Selector */}
          {collectEmi && (<div><label className="label">Select EMI *</label>
            {unpaidEmis.length === 0 ? <p className="text-success font-semibold text-sm py-3 text-center">✓ All EMIs paid</p> : (
            <div className="space-y-2 max-h-48 overflow-y-auto">{unpaidEmis.map(emi => {
                const sel = selectedEmiNo === emi.emi_no; const isOverdue = new Date(emi.due_date) < new Date();
                return (<button key={emi.id} type="button" onClick={() => setSelectedEmiNo(emi.emi_no)} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl border text-left transition-all ${sel ? 'border-brand-300 bg-brand-50/70' : 'border-surface-4 bg-white'}`}>
                  <div className="flex items-center gap-2">
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${sel ? 'bg-brand-500 border-brand-500' : 'border-surface-4'}`}>{sel && <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4"><path d="M20 6L9 17l-5-5"/></svg>}</div>
                    <span className={`text-sm font-semibold ${sel ? 'text-brand-700' : 'text-ink'}`}>EMI #{emi.emi_no}</span>
                  </div>
                  <div className="text-right"><span className="num text-sm font-semibold">{formatCurrency(emi.amount)}</span><br/><span className={`text-[10px] ${isOverdue ? 'text-danger' : 'text-ink-muted'}`}>{formatDateOnly(emi.due_date).split(' ').slice(0, 2).join(' ')}{isOverdue && ' overdue'}</span></div>
                </button>);
              })}</div>
            )}
          </div>)}

          {/* Mode */}
          <div>
            <label className="label">Payment Mode</label>
            <div className="flex gap-2">{(['CASH','UPI'] as const).map(m => (<button key={m} type="button" onClick={() => setMode(m)} className={`flex-1 py-3 rounded-xl border-2 text-sm font-semibold transition-all ${mode === m ? (m === 'CASH' ? 'border-success bg-success-light text-success' : 'border-info bg-info-light text-info') : 'border-surface-4 text-ink-muted'}`}>{m === 'CASH' ? 'Cash' : 'UPI / Online'}</button>))}</div>
          </div>
          {mode === 'UPI' && <input type="text" value={utr} onChange={e => setUtr(e.target.value)} placeholder="UTR / Reference *" className={`input ${!utr.trim() ? 'border-warning' : ''}`} />}
          {missingUtr && <p className="text-[11px] text-warning">UPI payment requires UTR / reference number.</p>}
          {mode === 'UPI' && qrDataUrl && <div className="flex flex-col items-center"><img src={qrDataUrl} alt="QR" className="w-44 h-44 rounded-xl border border-surface-4" /><p className="num text-xs text-ink-muted mt-1">{UPI_ID}</p></div>}

          <div className="card bg-surface-2 p-3">
            <p className="text-xs text-ink-muted">Collection Date and Time</p>
            <p className="text-sm font-semibold text-ink mt-1">{format(new Date(), 'd MMM yyyy, hh:mm a')}</p>
          </div>

          {!isAdmin && <input aria-label="Retailer pin" type="password" value={retailerPin} onChange={e => setRetailerPin(e.target.value)} placeholder="Retail PIN *" inputMode="numeric" className="input" />}
          {missingRetailPin && <p className="text-[11px] text-warning">Retail PIN is required to submit payment.</p>}
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} placeholder="Notes (optional)" className="input resize-none" />

          {/* Editable amounts */}
          <div className="card bg-surface-2 p-3 space-y-2">
            <p className="text-sm font-semibold text-ink-muted">Amounts <span className="font-normal text-brand-500">(editable)</span></p>
            {collectEmi && <div className="flex items-center gap-2"><label className="text-xs text-ink-muted w-20">EMI</label><input type="number" min={0} value={editEmi} onChange={e => setEditEmi(e.target.value)} placeholder={String(scheduledEmiAmount)} className="input flex-1 py-2" inputMode="numeric" /></div>}
            {collectFine && scheduledFine > 0 && <div className="flex items-center gap-2"><label className="text-xs text-danger w-20">Fine</label><input type="number" min={0} value={editFine} onChange={e => setEditFine(e.target.value)} placeholder={String(scheduledFine)} className="input flex-1 py-2" inputMode="numeric" /></div>}
            {collectCharge && scheduledCharge > 0 && <div className="flex items-center gap-2"><label className="text-xs text-warning w-20">Charge</label><input type="number" min={0} value={editCharge} onChange={e => setEditCharge(e.target.value)} placeholder={String(scheduledCharge)} className="input flex-1 py-2" inputMode="numeric" /></div>}
          </div>

          {/* Total */}
          <div className="flex items-center justify-between px-4 py-3 rounded-xl bg-brand-50 border border-brand-200">
            <span className="font-bold text-ink">Total Payable</span>
            <span className="num text-2xl font-bold text-brand-600">{formatCurrency(total)}</span>
          </div>

        </div>
        <div className="sticky bottom-0 z-30 bg-white border-t border-surface-4 p-3 pb-[calc(0.85rem+env(safe-area-inset-bottom))] flex gap-3 shadow-[0_-8px_20px_rgba(15,23,42,0.06)]">
          <button onClick={onClose} className="btn-secondary flex-1 py-3">Cancel</button>
          <button onClick={handleSubmit} disabled={cannotSubmit} className="btn-primary flex-1 py-3 disabled:opacity-50">{loading ? 'Saving...' : isAdmin ? 'Update Payment' : 'Submit Payment Request'}</button>
        </div>
      </div>
    </div>
  );
}
